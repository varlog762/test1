#Gregory Pereverzev 25.11.2019

from setuptools import setup

setup(name = 'vsearch',
      version = '1.0',
      description = 'The Head First Python Search Tools',
      author = 'Gregory Pereverzev',
      author_email = 'boot762@gmail.com',
      url = 'headfirstlab.com',
      py_modules = ['vsearch'])